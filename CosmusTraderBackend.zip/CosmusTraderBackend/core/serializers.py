# serializers.py
from rest_framework import serializers

# Add your serializers here